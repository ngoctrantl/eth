# Clachair

<sub>[wiktionary](https://en.wiktionary.org/wiki/clachair)</sub>
_(Scottish Gaelic)_ stonemason.

CLA bot you can sit on.
